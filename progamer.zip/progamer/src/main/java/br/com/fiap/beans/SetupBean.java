package br.com.fiap.beans;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import br.com.fiap.dao.SetupDao;
import br.com.fiap.model.Setup;
import br.com.fiap.model.User;

@Named
@RequestScoped
public class SetupBean {

	private Setup setup = new Setup();

	public void save() {
		
		User user = (User) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user");
		System.out.println(user.getEmail()+"");
		setup.setEmailUser(user.getEmail());
		
		new SetupDao().save(this.setup);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Setup Cadastrado com sucesso!"));
		System.out.println(this.setup);
	}
	
	public List<Setup> getSetups(){
		return new SetupDao().getAll();
	}
	
	public List<Setup> getSetupsByEmail(){
		User user = (User) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user");
		
		return new SetupDao().getAllByEmail(user.getEmail());
	}

	public Setup getSetup() {
		return setup;
	}

	public void setSetup(Setup setup) {
		this.setup = setup;
	}


}
