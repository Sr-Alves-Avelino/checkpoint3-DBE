package br.com.fiap.beans;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import br.com.fiap.dao.UserDao;
import br.com.fiap.model.User;

@Named
@RequestScoped
public class UserBean {

	private User user = new User();

	public void save() {
		new UserDao().save(this.user);
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("User Cadastrado com sucesso!"));
		System.out.println(this.user);
	}
	
	public List<User> getUsers(){
		return new UserDao().getAll();
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String login() {
		boolean exist = new UserDao().exist(user);
		if ( exist == true ) {
			FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("user", user);
			return "index?faces-redirect=true";
		}
		FacesContext.getCurrentInstance().getExternalContext().getFlash().setKeepMessages(true);		
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login Inválido!", "erro"));
		return "login?faces-redirect=true";		
	}
	
	public String logout() {
		FacesContext.getCurrentInstance().getExternalContext().getSessionMap().remove("user");
		return "login?faces-redirect=true";
	}
	
}
